
// Colio Wordpress Plugin. Admin

jQuery(document).ready(function($){

	
	/* "Settings"
	==============================================================*/
	
	// check if name was set when adding new portfilio
	$('#add_portfolio').submit(function(e){
		if( $(this).find('input[name="portfolio_name"]').val() == '' ) {
			e.preventDefault();
		}
	});
	
	// [colio] shortcode auto select on click
	$('.colio-shortcode-text').click(function(){
		if(document.body.createTextRange) { // IE
			var range = document.body.createTextRange();
			range.moveToElementText(this);
			range.select();			
		} else if(window.getSelection && document.createRange) { // other browsers
			var selection = window.getSelection();
			var range = document.createRange();
			range.selectNodeContents(this);
			selection.removeAllRanges();
			selection.addRange(range);
		}	
	});
	
	// make sure that "Check to remove!" checkbox is checked when deleting portfolio
	$('.colio-ps-remove').submit(function(e){
		if( ! $(this).find('input[name="confirm"]').is(':checked') ) {
			e.preventDefault();
		}
	});
	
	// portfolio settings accordion
	$('.colio-ps-open > a, .colio-ps-name > a, a.colio-ps-cancel').click(function(e){
		
		// find old and new sections
		var old = $('.colio-ps-opened'), 
			now = $(this).closest('.colio-ps-section');
		
		// close any open section
		old.removeClass('colio-ps-opened').find('.colio-ps-content').stop(true).slideUp(500, 'easeOutQuart');
		
		// if "close" button was clicked close section and remove cookie
		if(now[0] === old[0]) {
			document.cookie = 'colio_open_settings=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/';
			return false;
		}
		
		// open new section
		var toolbar = $('html').hasClass('wp-toolbar') ? 32 : 0;
		now.addClass('colio-ps-opened').find('.colio-ps-content').slideDown(300, 'easeOutQuart', function(){
			$('body, html').stop().animate({'scrollTop': now.offset().top + toolbar}, 500, 'easeOutQuart');
		});
		
		// save section ID in a cookie
		var expires = new Date().getTime() + 24 * 3600 * 1000; // one day
		document.cookie = 'colio_open_settings=' + now.attr('id') + '; expires=' + new Date(expires).toGMTString() + '; path=/';
		return false;
	});	
	
	// on page load check if any settings should be opened
	if( $('.colio-ps-opened').length > 0) {
		var section = $('.colio-ps-opened');
		var toolbar = $('html').hasClass('wp-toolbar') ? 32 : 0;
		section.find('.colio-ps-content').show();
		$('body, html').scrollTop(section.offset().top + toolbar);	
	}
		
	//  "Iris" color picker (WP 3.5+)
	if(typeof $.fn.wpColorPicker === 'function') {
		$('.colio-ps-color').wpColorPicker({palettes: false});
	}
	
	
	/* "Extra Photos" metabox 
	==============================================================*/
	
	// hold-and-drag thumbs to rearange using "jquery-ui-sortable" plugin
	if(typeof $.fn.sortable === 'function') {
		$('.colio-extra-photos').sortable({
			items: '> label',
			placeholder: 'colio-sortable-spot',
			opacity: 0.8,
			cursor: 'move'
		});
	}
	
	// remove photo from list when [x] is clicked
	$('.colio-extra-photos').on('click', '.colio-remove-photo', function(){
		$(this).parent().fadeOut(200, function(){
			$(this).remove();
		});
		return false;
	});
	
	// open "Media Menager" for photos selection (WP 3.5+)
	$('.colio-extra-photos .colio-upload-photo').click(function(){
						
		// check if "Media Manager" instance exist
		if(wp.media.frames.colio_media_manager) {
			wp.media.frames.colio_media_manager.open();
			return false;
		} 
		
		// otherwise create new instance and assign handlers
		var media_manager = wp.media({
			frame: 'select',
			title: 'Select Photos',
			multiple: true,
			library: {
				type: 'image'
			}, 
			button: {
				text: 'Done'
			}
		});
		wp.media.frames.colio_media_manager = media_manager;
		
		// assign handler to get what have been selected
		media_manager.on('select', function(e){
			var attachments = media_manager.state().get('selection');			
			attachments.each(function(attachment){
				var atts = attachment.attributes;
				var labels = $('.colio-extra-photos > label');
				var label = '<label>' + 
					'<input type="hidden" name="colio_extra_photos[]" value="' + atts.id + '">' +
					'<img src="' + atts.url + '" alt="">' +
					'<a href="#" class="colio-remove-photo" title="Remove photo"></a>' +
					'</label>';
				if(labels.length > 0) {
					labels.last().after(label);
				} else {
					$('.colio-extra-photos').prepend(label);
				}
			});
			
		});
		
		// now open media manager
		media_manager.open();
		return false;
	
	});
	
	
	/* "Social Links" metabox 
	==============================================================*/
	
	// when "Add Link" is clicked add a field to enter URL for social provider
	$('.colio-social-select #colio_social_add').click(function(){
	
		// metabox container
		var metabox = $('.colio-social-links');
	
		// get selected social provider from dropdown list
		var provider = metabox.find('#colio_social_select').val();
		var provider_name = metabox.find('#colio_social_select option[value="' + provider + '"]').text();
		var option = 'colio_social_links[' + provider + ']';
		
		// check if provider is not in use, in which case we move focus to it
		if( metabox.find('input[name="' + option + '"]').length ) {
			metabox.find('input[name="' + option + '"]').focus();
			return false;
		}
		
		// now add html for social provider
		var html = '<p><label>' +
						'<span>' + provider_name + '</span>' +
						'<input type="text" name="' + option + '" value="http://">' +
						'<a href="#" class="colio-social-remove">Remove</a>' + 
					'</label></p>';
							
		// add provider to document and change focus
		metabox.prepend(html).find('input[name="' + option + '"]').focus();
				
		// prevent default
		return false;
	});
	
	//  when "Remove" link is clicked remove social provider
	$('.colio-social-links').on('click', '.colio-social-remove', function(){
		$(this).closest('p').fadeOut(200, function(){ 
			$(this).remove(); 
		});
		return false;
	});
	
		
});

