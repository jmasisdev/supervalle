<?php
/** This template will return single colio items that will be loaded 
	by Colio using AJAX for displaying in viewport */
  
global $post;
   
// get portfolio ID query argument
$portfolio_id = isset($_GET['portfolio_id']) ? colio_sanitize_name($_GET['portfolio_id']) : '';

// exit if portfolio ID is missing in query
if( $portfolio_id == '' ) {
	_e('Oops! "portfolio_id" query argument is missing', 'colio');
	die();
}
 
// load portfolio settings from db
foreach( colio_list_options() as $option_id ) {
	$settings = colio_get_option($option_id);
	if( is_array($settings) && $settings['id'] == $portfolio_id ) {
		break;
	} else {
		$settings = false;
	}
}

// exit if settings was not found
if( !$settings ) {
	_e('Oops! portfolio was not found in settings', 'colio');
	die();
}

// get some settings for portfolio
$theme = $settings['colio']['theme'];
$switch_columns = $settings['colio']['switch_columns'];
$extra_photos_type = $settings['colio']['extra_photos'];

// get exatra photos for item
$extra_photos = get_post_meta($post->ID, '_colio_extra_photos', true);
   
// classes that will be assigned to "colio-item" wrap
$item_class = array();
if( sizeof($extra_photos) > 0 ) {
	$item_class[] = 'colio-has-side';
	$item_class[] = $extra_photos_type == 'feed' ? 'colio-side-feed' : 'colio-side-slider';
	if( $switch_columns ) {
		$item_class[] = 'colio-switch-columns';
	}
}
$item_class = apply_filters('colio_item_class', $item_class, $post);

// setup post data (required by the_content() and other template tags!)
setup_postdata($post);
?>

<div class="colio-item <?php echo esc_attr( implode(' ', $item_class) ); ?>">

	<?php if( $switch_columns ) { 
		colio_item_print_side($extra_photos, $extra_photos_type); } 
	?>
	
	<div class="colio-main">	
	
		<h3 class="colio-title"><?php the_title(); ?></h3>
		<div class="colio-subtitle"><?php 
			echo apply_filters('colio_item_subtitle', '', $post); 
		?></div>
		
		<?php do_action('colio_item_before_main_content', $post); ?>		
	
		<?php the_content(); ?>
		
		<?php do_action('colio_item_after_main_content', $post); ?>
						
		<?php do_action('colio_item_before_social_links', $post); ?>
		
		<?php 
			$social_links = get_post_meta($post->ID, '_colio_social_links', true);
			if( $social_links ) : ?>
				<ul class="colio-social">
				
			<?php 
				foreach( $social_links as $provider => $provider_url ) : 
				$provider_name = ucfirst( str_replace('_', '', $provider) );
			?>
			
			<li>
				<a class="<?php echo esc_attr($provider); ?>" href="<?php 
					echo esc_url($provider_url); ?>" title="<?php 
					echo esc_attr($provider_name); ?>" target="_blank"><?php echo esc_html($provider_name); ?></a>
			</li>
			
			<?php endforeach; ?>

		<?php endif; ?>
		
		<?php do_action('colio_item_after_social_links', $post); ?>		
	</div>
	
	<?php if( ! $switch_columns ) { 
		colio_item_print_side($extra_photos, $extra_photos_type); 
	} ?>
	
</div>


<?php

/**
* Function to print side content with extra photos
*
* @param $extra_photos array Array with item's extra photos
* @param $extra_photos_type string How extra photos should be displayed
* @return string HTML for side content
*/

function colio_item_print_side($extra_photos, $extra_photos_type) {
	global $post;
		
	// check if item has extra photos
	if( sizeof($extra_photos) > 0 ) :
	?>
	
	<div class="colio-side">
	
		<?php do_action('colio_item_before_side_extra', $post); ?>
		
		<?php if( $extra_photos_type == 'feed' ) : ?>
		
			<ul class="colio-feed">
							
				<?php foreach( $extra_photos as $attachment_id ) :
						$fullsize = wp_get_attachment_image_src($attachment_id, 'full');
						$meta = get_post($attachment_id);
				?>
				
				<li>
					<a class="fancybox" rel="group_<?php echo $post->ID; ?>" href="<?php 
						echo esc_url($fullsize[0]); ?>" title="<?php 
						echo esc_attr( trim(strip_tags($meta->post_excerpt)) ); ?>"><?php 
						echo wp_get_attachment_image($attachment_id, 'colio-extra-thumb'); ?>
					</a>
				</li>
					
				<?php endforeach; ?>
			
			</ul>
			
		<?php else : ?>
		
			<div class="colio-slider flexslider">
			
				<ul class="slides">
				
					<?php foreach( $extra_photos as $attachment_id ) : 
						$meta = get_post($attachment_id);
						$thumb = wp_get_attachment_image_src($attachment_id, 'thumbnail');  
					?>
					
					<li data-thumb="<?php echo $thumb[0]; ?>">
						<?php echo wp_get_attachment_image($attachment_id, 'full'); ?>
						<?php $caption = trim(strip_tags($meta->post_excerpt)); 
						if( $caption ) : ?>
							<div class="flex-caption"><?php echo $caption; ?></div>
						<?php endif; ?>
					</li>
					
					<?php endforeach; ?>
					
				</ul>
				
			</div>
		
		<?php endif; ?>
		
		<?php do_action('colio_item_after_side_extra', $post); ?>
	
	</div>
	
	<?php endif;
}
?>
