<?php 
/********************************************************************************

	Register settings for Colio -> Settings page using Wordpress "Settings API"

********************************************************************************/


/** 
* Function to register settings, add settings sections
* and fields
*/

function colio_register_settings(){

	// return if we have no portfolios
	if( !colio_list_options() ) {
		return;
	}
	
	// register settings for every portfolio so we can properly save 
	// them to "wp_options" table in WP database
	foreach( colio_list_options() as $option_id ) {

		// get portfolio settings
		$settings = colio_get_option($option_id);
	
		// define setting sections separately for every portfolio
		$general_section = 'colio_section_general_' . $option_id;
		$details_section = 'colio_section_details_' . $option_id;
	
		// add settings sections to the "colio_settings" page
		add_settings_section( $general_section, '', '', 'colio_settings' );
		add_settings_section( $details_section, '', '', 'colio_settings' );
		
		// all our settings fields for "General" and "Details Viewport" sections
		$general_fields = array(
			'id' => __('ID', 'colio'), 
			'name' => __('Name', 'colio'),
			'columns' => __('Columns', 'colio'),
			'groups' => __('Groups', 'colio'),
			'orderby' => __('Order Items', 'colio'),
			'order' => __('Order', 'colio'),
			'layout' => __('Grid Layout', 'colio'),
			'transition_duration' => __('Transition Duration', 'colio'),
			'transition_effect' => __('Transition Effect', 'colio'),
			'animate_position' => __('Animate Position', 'colio'),
			'pagination' => __('Pagination', 'colio'),
			'pagination_num' => __('Pagination Items', 'colio'),
			'filters' => __('Filters', 'colio'),
			'filters_style' => __('Filters Style', 'colio'),
			'filters_align' => __('Filters Alignment', 'colio'),
			'item_margin' => __('Item Margin', 'colio'),
			'item_padding' => __('Item Padding', 'colio'),
			'item_zoom' => __('Item Zoom', 'colio'),
			'item_button_text' => __('Item Button Text', 'colio'),
			'item_button_color' => __('Item Button Color', 'colio'),
			'item_hover_color' => __('Item Hover Color', 'colio'),
			'item_hover_opacity' => __('Item Hover Opacity', 'colio'),
			'item_title_color' => __('Item Title Color', 'colio'),
			'item_title_hover_color' => __('Item Title Hover Color', 'colio'),
			'item_title_font_size' => __('Item Title Font Size', 'colio'),
			'item_title_font' => __('Item Title Font', 'colio'),
			'item_excerpt' => __('Item Excerpt', 'colio'),
			'item_excerpt_length' => __('Item Excerpt Length', 'colio'),
			'item_excerpt_color' => __('Item Excerpt Color', 'colio'),
			'item_excerpt_font_size' => __('Item Excerpt Font Size', 'colio'),
			'item_excerpt_font' => __('Item Excerpt Font', 'colio')
		);
		
		$details_fields = array(
			'theme' => __('Theme', 'colio'),
			'theme_color' => __('Theme Color', 'colio'),
			'placement' => __('Placement', 'colio'),
			'extra_photos' => __('Extra Photos', 'colio'),
			'navigation' => __('Navigation', 'colio'),
			'switch_columns' => __('Switch Columns', 'colio'),
			'expand_duration' => __('Expand Duration', 'colio'),
			'expand_easing' => __('Expand Easing', 'colio'),
			'collapse_duration' => __('Collapse Duration', 'colio'),
			'collapse_easing' => __('Collapse Easing', 'colio'),
			'scroll_page' => __('Scroll Page', 'colio'),
			'scroll_duration' => __('Scroll Duration', 'colio'),
			'scroll_easing' => __('Scroll Easing', 'colio'),
			'sync_scroll' => __('Sync Scroll', 'colio'),
			'scroll_offset' => __('Scroll Offset', 'colio'),
			'content_fade_in' => __('Content Show Duration', 'colio'),
			'content_fade_out' => __('Content Hide Duration', 'colio'),
			'content_delay' => __('Content Show Delay', 'colio')
		);
		
		
		/* add setting fields to specific page/section and register callbacks to output input elements */
		foreach( $general_fields as $key => $title) {
			$args = array(
				'id' => $option_id, 
				'option' => COLIO_OPTION_PREFIX . $option_id, 
				's' => $settings
			);
			add_settings_field('colio_' . $key, $title, 'colio_output_field_' . $key, 'colio_settings', $general_section, $args);
		}
		
		foreach( $details_fields as $key => $title) {
			$args = array(
				'id' => $option_id, 
				'option' => COLIO_OPTION_PREFIX . $option_id . '[colio]', 
				's' => $settings['colio']
			);
			add_settings_field('colio_' . $key, $title, 'colio_output_field_' . $key, 'colio_settings', $details_section, $args);
		}

		// register settings
		register_setting( 'colio_settings_group_' . $option_id, COLIO_OPTION_PREFIX . $option_id, 'colio_sanitize_settings' );
	}

}

add_action('admin_init', 'colio_register_settings');


/**
* Function to sanitize & copy values from input array to $args array
*
* @param array $args	Resulting array (passed by reference)
* @param array $input	Input array as key, value pairs
* @param string $name	Key name to copy 
* @param string $type	Key type
* @return				Nothing
*/

function colio_input_args(&$args, $input, $name, $type = '') {
		
	if( isset($input[$name]) && $input[$name] != '' ) {
		switch($type) {
			case "int": 
				$args[$name] = intval($input[$name]); 
				break;
			case "id":
				$args[$name] = colio_sanitize_name($input[$name]);
				break;
			case "array":
				$args[$name] = is_array($input[$name]) ? $input[$name] : array();
				break;
			case "color":
				$color = strtolower( trim($input[$name]) );
				if( preg_match('/^#([a-f0-9]{3}){1,3}$/', $color) ) {
					$args[$name] = $color;
				}
				break;
			case "opacity":
				$opacity = floatval($input[$name]);
				if($opacity > 0 && $opacity <= 1) {
					$args[$name] = $opacity;
				}
				break;
			case "font_size":
				$font_size = intval($input[$name]);
				if($font_size > 0) {
					$args[$name] = $font_size;
				}
				break;
			default:
				$args[$name] = trim(strip_tags($input[$name])); 
		}		
	}
	
	// handle checkboxes
	if($type == 'check') {
		$args[$name] = isset($input[$name]) ? true : false;
	}
}


/**
* Function to sanitize input when portfolio settings are submitted.
* It uses global $colio_defaults array as fallback for settings
*
* @param array $input Array with form data, where name is a key
*/

function colio_sanitize_settings( $input ){
	global $colio_defaults;
	
	// our clean settings that we will save to DB
	$clean = $colio_defaults;
	
	// sanitize & copy values from input
	colio_input_args($clean, $input, '_id', 'id');
	colio_input_args($clean, array('id' => $input['name']), 'id', 'id');
	colio_input_args($clean, $input, 'name');
	colio_input_args($clean, $input, 'columns', 'int');
	colio_input_args($clean, $input, 'groups', 'array');
	colio_input_args($clean, $input, 'orderby');
	colio_input_args($clean, $input, 'order');
	colio_input_args($clean, $input, 'layout');
	colio_input_args($clean, $input, 'pagination', 'check');
	colio_input_args($clean, $input, 'pagination_num', 'int');
	colio_input_args($clean, $input, 'transition_duration', 'int');
	colio_input_args($clean, $input, 'transition_effect');
	colio_input_args($clean, $input, 'animate_position', 'check');
	colio_input_args($clean, $input, 'filters', 'check');
	colio_input_args($clean, $input, 'filters_style');
	colio_input_args($clean, $input, 'filters_align');
	colio_input_args($clean, $input, 'item_margin', 'int');
	colio_input_args($clean, $input, 'item_padding', 'check');
	colio_input_args($clean, $input, 'item_zoom', 'check');
	colio_input_args($clean, $input, 'item_button_color', 'color');
	colio_input_args($clean, $input, 'item_button_text');
	colio_input_args($clean, $input, 'item_hover_color', 'color');
	colio_input_args($clean, $input, 'item_hover_opacity', 'opacity');
	colio_input_args($clean, $input, 'item_title_color', 'color');
	colio_input_args($clean, $input, 'item_title_hover_color', 'color');
	colio_input_args($clean, $input, 'item_title_font_size', 'font_size');
	colio_input_args($clean, $input, 'item_title_font');
	colio_input_args($clean, $input, 'item_excerpt', 'check');
	colio_input_args($clean, $input, 'item_excerpt_length', 'int');
	colio_input_args($clean, $input, 'item_excerpt_color', 'color');
	colio_input_args($clean, $input, 'item_excerpt_font_size', 'font_size');
	colio_input_args($clean, $input, 'item_excerpt_font');

	colio_input_args($clean['colio'], array('id' => 'colio_viewport_' . $input['_id']), 'id', 'id');
	colio_input_args($clean['colio'], $input['colio'], 'theme');
	colio_input_args($clean['colio'], $input['colio'], 'theme_color', 'color');
	colio_input_args($clean['colio'], $input['colio'], 'placement');
	colio_input_args($clean['colio'], $input['colio'], 'extra_photos');
	colio_input_args($clean['colio'], $input['colio'], 'navigation', 'check');
	colio_input_args($clean['colio'], $input['colio'], 'switch_columns', 'check');
	colio_input_args($clean['colio'], $input['colio'], 'expand_duration', 'int');
	colio_input_args($clean['colio'], $input['colio'], 'expand_easing');
	colio_input_args($clean['colio'], $input['colio'], 'collapse_duration', 'int');
	colio_input_args($clean['colio'], $input['colio'], 'collapse_easing');
	colio_input_args($clean['colio'], $input['colio'], 'scroll_page', 'check');
	colio_input_args($clean['colio'], $input['colio'], 'scroll_duration', 'int');
	colio_input_args($clean['colio'], $input['colio'], 'scroll_easing');
	colio_input_args($clean['colio'], $input['colio'], 'sync_scroll', 'check');
	colio_input_args($clean['colio'], $input['colio'], 'scroll_offset', 'int');
	colio_input_args($clean['colio'], $input['colio'], 'content_fade_in', 'int');
	colio_input_args($clean['colio'], $input['colio'], 'content_fade_out', 'int');
	colio_input_args($clean['colio'], $input['colio'], 'content_delay', 'int');
		
	// display notice
	add_settings_error('colio_plugin_notice', 'colio_plugin', __('Portfolio settings updated!', 'colio'), 'updated');
				
	// return sanitized settings
	return $clean;
}


/** 
* Functions to output contents of different settings fields for "General" settings section
*
* @param array $args Array with keys "id" - portfolio id, "option" - wp_options entry
*					 to save settings, "s" - settings for portfolio
*/

function colio_output_field_id( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[id]" readonly value="' . $s['id'] . '">';
}

function colio_output_field_name( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[name]" value="' . $s['name'] . '">';
	echo '<span class="colio-help-icon" title="' . 
	__('Renaming portfolio will require you to update shortcode that you use on your website!', 'colio') . '"></span>';
}

function colio_output_field_columns( $args ) {
	extract($args);
	
	$col_options = '';
	foreach( array(2,3,4,5) as $col ) {
		$col_options .= '<option value="' . $col . '" ' . selected($col, $s['columns'], false) . '>' . $col . '</option>';
	} 
	echo '<select name="' . $option . '[columns]">' . $col_options . '</select>';
	echo '<p class="description">' . __('Number of columns in portfolio grid', 'colio') . '</p>';
}

function colio_output_field_groups( $args ) {
	extract($args);
	$options = array();
	$groups = get_terms('colio_group', 'orderby=count&hide_empty=0');
	
	if( $groups && !is_wp_error($groups) ) {
		foreach( $groups as $group ) {
			$selected = selected(in_array($group->term_id, $s['groups']), true, false);
			$options[] = '<option value="' . $group->term_id . '" ' . $selected . '>' . esc_html($group->name) . '</option>';
		}
	} else {
		$options[] = '<option value="">&nbsp; - &nbsp;</option>';
	} 
	echo '<select name="' . $option . '[groups][]" multiple>' . implode('', $options) . '</select>';
	echo '<p class="description">' . __('Select one or few item groups to show in portfolio', 'colio') . '</p>';
}

function colio_output_field_orderby( $args ) {
	extract($args);

	$order_options = '';
	$order = array('none', 'ID', 'date', 'author', 'title', 'name', 'modified', 'rand');
	foreach( $order as $ord) {
		$order_options .= '<option value="' . $ord . '" ' . selected($ord, $s['orderby'], false) . '>' . 
		ucfirst($ord) . '</option>';
	} 
	echo '<select name="' . $option . '[orderby]">' . $order_options . '</select>';
	echo '<p class="description">' . __('Sort items in portfolio by parameter', 'colio') . '</p>';
}

function colio_output_field_order( $args ) {
	extract($args); 
	echo '<select name="' . $option . '[order]">';
	echo '<option value="DESC" ' . selected('DESC', $s['order'], false) . '>DESC</option>';
	echo '<option value="ASC" ' . selected('ASC', $s['order'], false) . '>ASC</option>';
	echo '</select>';
}

function colio_output_field_layout( $args ) {
	extract($args); 
	echo '<label><input type="radio" name="' . $option . '[layout]" value="fitRows" ' . 
	 checked('fitRows', $s['layout'], false) . '> Normal</label>';
	echo '<label><input type="radio" name="' . $option . '[layout]" value="masonry" ' . 
	 checked('masonry', $s['layout'], false) . '> Masonry</label>';
	echo '<p class="description">' . __('Grid layout type', 'colio') . '</p>';
}

function colio_output_field_transition_duration( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[transition_duration]" value="' . $s['transition_duration'] . '">';
	echo '<p class="description">' . __('Duration of all grid transitions, ms', 'colio') . '</p>';
}

function colio_output_field_transition_effect( $args ) {
	extract($args); 
	echo '<label><input type="radio" name="' . $option . '[transition_effect]" value="default" ' . 
	 checked('default', $s['transition_effect'], false) . '> Default</label>';
	echo '<label><input type="radio" name="' . $option . '[transition_effect]" value="fade" ' . 
	 checked('fade', $s['transition_effect'], false) . '> Fade</label>';
	echo '<label><input type="radio" name="' . $option . '[transition_effect]" value="rotate" ' . 
	 checked('rotate', $s['transition_effect'], false) . '> Rotate</label>';
	echo '<p class="description">' . __('Animation effect when items in grid replace each other','colio') . '</p>';
}

function colio_output_field_animate_position( $args ) {
	extract($args); 
	echo '<label><input type="checkbox" name="' . $option . '[animate_position]" value="1"' . 
	checked(1, $s['animate_position'], false) . '> ' . __('Enable', 'colio') . '</label>';
	echo '<p class="description">' . __('When checked, use smooth animation to realign items in grid', 'colio') . '</p>';
}

function colio_output_field_pagination( $args ) {
	extract($args); 
	echo '<label><input type="checkbox" name="' . $option . '[pagination]" value="1"' . 
	checked(1, $s['pagination'], false) . '> ' . __('Enable', 'colio') . '</label>';
	echo '<p class="description">' . __('Enable pagination', 'colio') . '</p>';
}

function colio_output_field_pagination_num( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[pagination_num]" value="' . $s['pagination_num'] . '">';
	echo '<p class="description">' . __('Display this number of items per page', 'colio') . '</p>';
} 

function colio_output_field_filters( $args ) {
	extract($args); 
	echo '<label><input type="checkbox" name="' . $option . '[filters]" value="1"' . 
	checked(1, $s['filters'], false) . '> ' . __('Enable', 'colio') . '</label>';
	echo '<p class="description">' . __('Enable portfolio filters menu', 'colio') . '</p>';
}

function colio_output_field_filters_style( $args ) {
	extract($args); 
	echo '<label><input type="radio" name="' . $option . '[filters_style]" value="list" ' . 
	 checked('list', $s['filters_style'], false) . '> List</label>';
	echo '<label><input type="radio" name="' . $option . '[filters_style]" value="select" ' . 
	 checked('select', $s['filters_style'], false) . '> Select</label>';
	echo '<p class="description">' . __('Display portfolio filters as list or as select box','colio') . '</p>';
}

function colio_output_field_filters_align( $args ) {
	extract($args); 
	echo '<label><input type="radio" name="' . $option . '[filters_align]" value="left" ' .
	checked('left', $s['filters_align'], false) . '> Left</label>';
	echo '<label><input type="radio" name="' . $option . '[filters_align]" value="right" ' . 
	checked('right', $s['filters_align'], false) . '> Right</label>';
	echo '<p class="description">' . __('Align filters menu to the right or to the left','colio') . '</p>';
}

function colio_output_field_item_margin( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[item_margin]" value="' . 
	esc_attr($s['item_margin']) . '">';
	echo '<p class="description">' . __('Outer margin for items in grid', 'colio') . '</p>';
}

function colio_output_field_item_padding( $args ) {
	extract($args); 
	echo '<label><input type="checkbox" name="' . $option . '[item_padding]" value="1" ' .
	checked(1, $s['item_padding'], false) . '> Enable</label>';
	echo '<p class="description">' . __('Add small padding around item thumbs', 'colio') . '</p>';
}

function colio_output_field_item_zoom( $args ) {
	extract($args); 
	echo '<label><input type="checkbox" name="' . $option . '[item_zoom]" value="1" ' .
	checked(1, $s['item_zoom'], false) . '> Enable</label>';
	echo '<p class="description">' . __('Whether to zoom item thumb on mouse hover', 'colio') . '</p>';
}

function colio_output_field_item_button_color( $args ) {
	extract($args); 
	echo '<input type="text" class="colio-ps-color" name="' . 
	$option . '[item_button_color]" value="' . $s['item_button_color'] . '" data-default-color="' .
	$s['item_button_color'] . '">';
}

function colio_output_field_item_button_text( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[item_button_text]" value="' .
	esc_attr($s['item_button_text']) . '">';
}

function colio_output_field_item_hover_color( $args ) {
	extract($args); 
	echo '<input type="text" class="colio-ps-color" name="' . 
	$option . '[item_hover_color]" value="' . $s['item_hover_color'] . '" data-default-color="' .
	$s['item_hover_color'] . '">';
	echo '<p class="description">' . __('Item thumb overlay color on mouse hover', 'colio') . '</p>';
}

function colio_output_field_item_hover_opacity( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[item_hover_opacity]" value="' .
	$s['item_hover_opacity'] . '">';
	echo '<p class="description")>' . __('Item thumb overlay opacity on mouse hover', 'colio') . '</p>';
}

function colio_output_field_item_title_color( $args ) {
	extract($args); 
	echo '<input type="text" class="colio-ps-color" name="' . 
	$option . '[item_title_color]" value="' . $s['item_title_color'] . '" data-default-color="' .
	$s['item_title_color'] . '">';
}

function colio_output_field_item_title_hover_color( $args ) {
	extract($args); 
	echo '<input type="text" class="colio-ps-color" name="' . 
	$option . '[item_title_hover_color]" value="' . $s['item_title_hover_color'] . '" data-default-color="' .
	$s['item_title_hover_color'] . '">';
}

function colio_output_field_item_title_font_size( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[item_title_font_size]" value="' .
	esc_attr($s['item_title_font_size']) . '">';
}

function colio_output_field_item_title_font( $args ) {
	extract($args);
	
	$font_options = '';
	$safe_fonts = array('inherit', 'Arial', 'Times New Roman', 'Georgia', 'Tahoma', 'Impact', 'Palatino Linotype', 'Century Gothic', 'Lucida Sans Unicode', 'Lucida Console', 'Verdana', 'Trebuchet MS', 'Courier New');
	foreach( $safe_fonts as $font) {
		$font_options .= '<option value="' . $font . '" ' . selected($font, $s['item_title_font'], false) . '>' . 
		$font . '</option>';
	} 
	echo '<select name="' . $option . '[item_title_font]">' . $font_options . '</select>';
}

function colio_output_field_item_excerpt( $args ) {
	extract($args); 
	echo '<label><input type="checkbox" name="' . $option . '[item_excerpt]" value="1"' . 
	checked(1, $s['item_excerpt'], false) . '> ' . __('Show excerpt', 'colio') . '</label>';
}

function colio_output_field_item_excerpt_length( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[item_excerpt_length]" value="' .
	esc_attr($s['item_excerpt_length']) . '">';
	echo '<p class="description">' . __('Number of words in excerpt', 'colio') . '</p>';
}

function colio_output_field_item_excerpt_color( $args ) {
	extract($args); 
	echo '<input type="text" class="colio-ps-color" name="' . 
	$option . '[item_excerpt_color]" value="' . $s['item_excerpt_color'] . '" data-default-color="' .
	$s['item_excerpt_color'] . '">';
}

function colio_output_field_item_excerpt_font_size( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[item_excerpt_font_size]" value="' .
	esc_attr($s['item_excerpt_font_size']) . '">';
}

function colio_output_field_item_excerpt_font( $args ) {
	extract($args);
	
	$font_options = '';
	$safe_fonts = array('inherit', 'Arial', 'Times New Roman', 'Georgia', 'Tahoma', 'Impact', 'Palatino Linotype', 'Century Gothic', 'Lucida Sans Unicode', 'Lucida Console', 'Verdana', 'Trebuchet MS', 'Courier New');
	foreach( $safe_fonts as $font) {
		$font_options .= '<option value="' . $font . '" ' . selected($font, $s['item_excerpt_font'], false) . '>' . 
		$font . '</option>';
	} 
	echo '<select name="' . $option . '[item_excerpt_font]">' . $font_options . '</select>';
}


/** 
* Functions to output contents for different settings fields for "Details Viewport" settings section
*
* @param array $args Array with keys "id" - portfolio id, "option" - wp_options entry
*					 to save settings, "s" - settings for portfolio
*/

function colio_output_field_theme( $args ) {
	extract($args); 
	echo '<label><input type="radio" name="' . $option . '[theme]" value="black" ' . 
		checked('black', $s['theme'], false) . '> '. _x('Black', 'theme option', 'colio') . '</label>';
	echo '<label><input type="radio" name="' . $option . '[theme]" value="white" ' . 
		checked('white', $s['theme'], false) . '> '. _x('White', 'placement option', 'colio') . '</label>';
	echo '<p class="description">' . __('Item details theme', 'colio') . '</p>';
}

function colio_output_field_theme_color( $args ) {
	extract($args); 
	echo '<input type="text" class="colio-ps-color" name="' . 
	$option . '[theme_color]" value="' . $s['theme_color'] . '" data-default-color="' .
	$s['theme_color'] . '">';
	echo '<p class="description">' . __('Select base color for a theme', 'colio') . '</p>';
}

function colio_output_field_placement( $args ) {
	extract($args); 
	echo '<label><input type="radio" name="' . $option . '[placement]" value="before" ' . 
		checked('before', $s['placement'], false) . '> '. _x('Before', 'placement option', 'colio') . '</label>';
	echo '<label><input type="radio" name="' . $option . '[placement]" value="inside" ' . 
		checked('inside', $s['placement'], false) . '> '. _x('Inside', 'placement option', 'colio') . '</label>';
	echo '<label><input type="radio" name="' . $option . '[placement]" value="after" ' . 
		checked('after', $s['placement'], false) . '> '. _x('After', 'placement option', 'colio') . '</label>';
	echo '<p class="description">' . __('Item details placement, relative to the portfolio grid', 'colio') . '</p>';
}

function colio_output_field_extra_photos( $args ) {
	extract($args); 
	echo '<label><input type="radio" name="' . $option . '[extra_photos]" value="feed" ' . 
		checked('feed', $s['extra_photos'], false) . '> '. __('Feed', 'colio') . '</label>';
	echo '<label><input type="radio" name="' . $option . '[extra_photos]" value="slider" ' . 
		checked('slider', $s['extra_photos'], false) . '> '. __('Slider', 'colio') . '</label>';
	echo '<p class="description">' . __('Display item "Extra photos" as photo feed or slider', 'colio') . '</p>';
}

function colio_output_field_navigation( $args ) {
	extract($args); 
	echo '<label><input type="checkbox" name="' . $option . '[navigation]" value="1" ' . 
	checked(1, $s['navigation'], false) . '> ' . __('Enable navigation', 'colio') . '</label>';
	echo '<p class="description">' . __('Enable next/prev controls inside details viewport', 'colio') . '</p>';
}

function colio_output_field_switch_columns( $args ) {
	extract($args); 
	echo '<label><input type="checkbox" name="' . $option . '[switch_columns]" value="1" ' . 
	checked(1, $s['switch_columns'], false) . '> ' . __('Switch Columns', 'colio') . '</label>';
	echo '<p class="description">' . __('Swap main/side content columns in details viewport', 'colio') . '</p>';
}

function colio_output_field_expand_duration( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[expand_duration]" value="' . esc_attr($s['expand_duration']) . '">';
	echo '<p class="description">' . __('Details viewport expand duration, ms', 'colio') . '</p>';
}

function colio_output_field_expand_easing( $args ) {
	extract($args); 
	$easing = array(
		'swing', 'linear', 
		'easeInQuad', 'easeOutQuad', 'easeInOutQuad',
		'easeInCubic', 'easeOutCubic', 'easeInOutCubic',
		'easeInQuart', 'easeOutQuart', 'easeInOutQuart', 
		'easeInQuint', 'easeOutQuint', 'easeInOutQuint', 
		'easeInSine', 'easeOutSine', 'easeInOutSine', 
		'easeInExpo', 'easeOutExpo', 'easeInOutExpo', 
		'easeInCirc', 'easeOutCirc', 'easeInOutCirc', 
		'easeInBack', 'easeOutBack', 'easeInOutBack'
	);
	
	$options = '';
	foreach( $easing as $e ) {
		$options .= '<option value="' . $e . '" ' . selected($e, $s['expand_easing'], false) . '>' . $e . '</option>';
	}
	
	echo '<select name="' . $option . '[expand_easing]">' . $options . '</select>';
	echo '<p class="description">' . __('Details viewport expand easing', 'colio') . '</p>';
}

function colio_output_field_collapse_duration( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[collapse_duration]" value="' . 
	esc_attr($s['collapse_duration']) . '">';
	echo '<p class="description">' . __('Details viewport collapse duration, ms', 'colio') . '</p>';
}

function colio_output_field_collapse_easing( $args ) {
	extract($args); 
	$easing = array(
		'swing', 'linear', 
		'easeInQuad', 'easeOutQuad', 'easeInOutQuad',
		'easeInCubic', 'easeOutCubic', 'easeInOutCubic',
		'easeInQuart', 'easeOutQuart', 'easeInOutQuart', 
		'easeInQuint', 'easeOutQuint', 'easeInOutQuint', 
		'easeInSine', 'easeOutSine', 'easeInOutSine', 
		'easeInExpo', 'easeOutExpo', 'easeInOutExpo', 
		'easeInCirc', 'easeOutCirc', 'easeInOutCirc', 
		'easeInBack', 'easeOutBack', 'easeInOutBack'
	);
	
	$options = '';
	foreach( $easing as $e ) {
		$options .= '<option value="' . $e . '" ' . selected($e, $s['collapse_easing'], false) . '>' . $e . '</option>';
	}
	
	echo '<select name="' . $option . '[collapse_easing]">' . $options . '</select>';
	echo '<p class="description">' . __('Details viewport collapse easing', 'colio') . '</p>';
}



function colio_output_field_scroll_page( $args ) {
	extract($args); 
	echo '<label><input type="checkbox" name="' . $option . '[scroll_page]" value="1" ' . 
	checked(1, $s['scroll_page'], false) . '> ' . __('Enable', 'colio') . '</label>';
	echo '<p class="description">' . __('Automatically scroll page to details viewport on expand', 'colio') . '</p>';
}

function colio_output_field_scroll_duration( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[scroll_duration]" value="' . 
	esc_attr($s['scroll_duration']) . '">';
	echo '<p class="description">' . __('Duration for page scroll, ms', 'colio') . '</p>';
}

function colio_output_field_scroll_easing( $args ) {
	extract($args); 
	$easing = array(
		'swing', 'linear', 
		'easeInQuad', 'easeOutQuad', 'easeInOutQuad',
		'easeInCubic', 'easeOutCubic', 'easeInOutCubic',
		'easeInQuart', 'easeOutQuart', 'easeInOutQuart', 
		'easeInQuint', 'easeOutQuint', 'easeInOutQuint', 
		'easeInSine', 'easeOutSine', 'easeInOutSine', 
		'easeInExpo', 'easeOutExpo', 'easeInOutExpo', 
		'easeInCirc', 'easeOutCirc', 'easeInOutCirc', 
		'easeInBack', 'easeOutBack', 'easeInOutBack'
	);
	
	$options = '';
	foreach( $easing as $e ) {
		$options .= '<option value="' . $e . '" ' . selected($e, $s['scroll_easing'], false) . '>' . $e . '</option>';
	}
	
	echo '<select name="' . $option . '[scroll_easing]">' . $options . '</select>';
	echo '<p class="description">' . __('Easing for page scroll', 'colio') . '</p>';
}

function colio_output_field_sync_scroll( $args ) {
	extract($args); 
	echo '<label><input type="checkbox" name="' . $option . '[sync_scroll]" value="1" ' . 
	checked(1, $s['sync_scroll'], false) . '> ' . __('Enable', 'colio') . '</label>';
	echo '<p class="description">' . __('Sync page scroll with expand/collapse of details viewport', 'colio') . '</p>';
}

function colio_output_field_scroll_offset( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[scroll_offset]" value="' . 
	esc_attr($s['scroll_offset']) . '">';
	echo '<p class="description">' . __('Details viewport offset from the top of page when it\'s expanded, px', 'colio') . '</p>';
}

function colio_output_field_content_fade_in( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[content_fade_in]" value="' . 
	esc_attr($s['content_fade_in']) . '">';
	echo '<p class="description">' . __('Content fade in duration, ms', 'colio') . '</p>';
}

function colio_output_field_content_fade_out( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[content_fade_out]" value="' . 
	esc_attr($s['content_fade_out']) . '">';
	echo '<p class="description">' . __('Content fade out duration, ms', 'colio') . '</p>';

}

function colio_output_field_content_delay( $args ) {
	extract($args); 
	echo '<input type="text" name="' . $option . '[content_delay]" value="' . 
	esc_attr($s['content_delay']) . '">';
	echo '<p class="description">' . __('Content fade in delay, ms', 'colio') . '</p>';
}

?>