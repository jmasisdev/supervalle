<?php

/********************************************************************************
		
	A set of functions to work with plugin options that will be stored 
	in wp_options table of Wordpress database
	
********************************************************************************/


// list with all options and their entries in wp_options table
define('COLIO_OPTION_LIST', 'colio_options');
if( false === get_option( COLIO_OPTION_LIST ) ) {
	add_option( COLIO_OPTION_LIST, array(), '', true );
}

// prefix for storing actual options in wp_options table
define('COLIO_OPTION_PREFIX', 'colio_option_');


/**
* Function to get list with existing options
* 
* @return array Array with options
*/

function colio_list_options(){
	return array_keys( get_option( COLIO_OPTION_LIST ) );
}


/**
* Function to get option
*
* @param string $option Option name
* @return mixed Option value. False if option does not exist
*/

function colio_get_option( $option ) {
	$option_list = get_option( COLIO_OPTION_LIST );
	if ( !isset($option_list[$option]) ) return false;
	return get_option( $option_list[$option] );
}


/**
* Function to add option
*
* @param string $option Option name
* @param array $value Option value
* @return bool True if option was added. False if option already exists
*/

function colio_add_option( $option, $value ) {
	$option_list = get_option( COLIO_OPTION_LIST );
	if( isset($option_list[$option]) ) return false;
	$option_list[$option] = COLIO_OPTION_PREFIX . $option;
	update_option( COLIO_OPTION_LIST, $option_list);
	return update_option( COLIO_OPTION_PREFIX . $option, $value );
}


/**
* Function to update option
*
* @param string $option Option name
* @param array $value New option value
* @return bool True if option was updated. False if option does not exist
*/

function colio_update_option( $option, $value ) {
	$option_list = get_option( COLIO_OPTION_LIST );
	if ( !isset( $option_list[$option]) ) return false;
	return update_option( $option_list[$option], $value );
}


/**
* Function to remove option
*
* @param string $option Option name
* @return bool True if option was removed. False if option does not exist
*/

function colio_remove_option( $option ) {
	$option_list = get_option( COLIO_OPTION_LIST );
	if ( !isset( $option_list[$option]) ) return false;
	delete_option( $option_list[$option] );
	unset( $option_list[$option] );
	return update_option( COLIO_OPTION_LIST, $option_list );
}


/**
* Function to rename option
* 
* @param $option_old Old option name
* @param $option_new New option name
* @return True if option was successfully renamed. False otherwise
*/

function colio_rename_option($option_old, $option_new){
	$value = colio_get_option($option_old);
	if( $value === false ) return false;
	colio_remove_option($option_old);
	return colio_add_option($option_new, $value);
}


?>