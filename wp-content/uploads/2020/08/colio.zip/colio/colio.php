<?php
/*
Plugin Name: Colio
Plugin URI: http://plugins.gravitysign.com/colio-wp/
Description: With this plugin you will be able to create filterable, multi-column portfolio with the expand & preview feature, that will allow your site visitors to check details of your portfolio items in convenient, user-friendly way.
Version: 2.3.4
Author: flGravity
Author URI: http://codecanyon.net/user/flGravity
*/


/**
* Global constants
*/

define('COLIO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('COLIO_PLUGIN_URL', plugins_url('/colio/'));
define('COLIO_PLUGIN_DOCS', COLIO_PLUGIN_URL . 'docs/');


/**
* Includes
*/

require(COLIO_PLUGIN_DIR . 'includes/options.php');
require(COLIO_PLUGIN_DIR . 'includes/post.php');
require(COLIO_PLUGIN_DIR . 'includes/admin.php');
require(COLIO_PLUGIN_DIR . 'includes/settings.php');


/**
* Enable localization
*/

function colio_load_textdomain(){
	load_plugin_textdomain('colio', false, dirname(plugin_basename(__FILE__)) .  '/languages/');
}

add_action('plugins_loaded', 'colio_load_textdomain');


/**
* Flush rewrite rules when registering custom post types
*/

function colio_flush_rewrites(){
	
	// register all custom post types and taxonomies
	colio_register_post_type();
	colio_register_group_taxonomy();
	colio_register_tag_taxonomy();
	
	// now flush rewrite rules
	flush_rewrite_rules();
}

register_activation_hook( __FILE__, 'colio_flush_rewrites');
register_deactivation_hook( __FILE__, 'flush_rewrite_rules');


/**
* Define image sizes. When you change any of image sizes below you
* should regenerate tumbnails using some plugin, like "Regenerate Thumbnails" 
* https://wordpress.org/plugins/regenerate-thumbnails/
*/

// extra photos thumbs
add_image_size('colio-extra-thumb', 150, 150, true);

// portfolio grid thumbs (crop and no-crop)
add_image_size('colio-item-thumb', 460, 300, true);
add_image_size('colio-item-thumb-nocrop', 460, 300);


/*
* Function to display links to colio groups in Admin, possibly with number of items
*
* @param array $groups Array with group IDs
* @param bool $items_count Show total number of items in group, default is false
* @return string HTML with groups as links
*/

function colio_list_groups( $groups, $items_count = false ){
	if( $groups && is_array($groups) ) {	
		$group_links = array();
		$group_url = 'edit-tags.php?taxonomy=colio_group&post_type=colio_item';
		foreach( $groups as $id) {
			$group = get_term($id, 'colio_group');
			$group_items = get_objects_in_term($group->term_id, 'colio_group', array('order' => 'ASC'));
			$group_total = $items_count ? ' (' . count($group_items) . ')' : '';
			$group_links[] = '<a href="' . $group_url . '">' . esc_html($group->name) . $group_total . '</a>';
		}
		return  implode(', ', $group_links);
	} else {
		return '-';
	}
}

/** 
* Function to convert portfolio name "My Portfolio" to 
* its sanitized form "my_portfolio" 
*	
* @param string $name Portfolio name
* @return string Sanitized name
*/

function colio_sanitize_name($name) {
	return str_replace('-', '_', sanitize_title($name));
}


/**
* Enqueue all frontend scripts & styles for plugin
*/

function colio_enqueue_scripts(){

	wp_enqueue_style('colio', COLIO_PLUGIN_URL . 'colio.css', array());
	wp_enqueue_style('colio-grid', COLIO_PLUGIN_URL . 'grid.css', array('colio'));
	wp_enqueue_style('colio-themes', COLIO_PLUGIN_URL . 'themes.css', array('colio', 'colio-grid'));
	wp_enqueue_script('jquery-easing', COLIO_PLUGIN_URL . 'jquery.easing.1.3.js', array('jquery'), '1.3', true);
	wp_enqueue_script('imagesloaded', COLIO_PLUGIN_URL . 'imagesloaded.min.js', array('jquery'), '3.1.7', true);	
	wp_enqueue_script('isotope', COLIO_PLUGIN_URL . 'jquery.isotope.min.js', array('jquery', 'jquery-easing'), '2.2', true);
	wp_enqueue_script('colio', COLIO_PLUGIN_URL . 'jquery.colio.min.js', array('jquery', 'jquery-easing'), '1.6.1', true);
	wp_enqueue_script('colio-init', COLIO_PLUGIN_URL . 'init.js', array('colio', 'isotope', 'imagesloaded'), false, true);
	// link flexslider
	wp_enqueue_style('flexslider', COLIO_PLUGIN_URL . 'flexslider/flexslider.css', array(), '2.5.0');
	wp_enqueue_script('flexslider', COLIO_PLUGIN_URL . 'flexslider/jquery.flexslider.min.js', array('jquery'), '2.5.0', true);
	// link fancybox
	wp_enqueue_style('fancybox', COLIO_PLUGIN_URL . 'fancybox/jquery.fancybox.css', array(), '2.1.5');
	wp_enqueue_script('fancybox', COLIO_PLUGIN_URL . 'fancybox/jquery.fancybox.min.js', array('jquery'), '2.1.5', true);	
}

add_action('wp_enqueue_scripts', 'colio_enqueue_scripts');


/**
* Function to print custom styles using "wp_head" hook.
*/

function colio_print_styles(){
	if( !colio_list_options() ) { 
		return; 
	} 
	?>
	
	<style type="text/css">

	<?php foreach( colio_list_options() as $option_id ) : extract(colio_get_option($option_id));			
		
		// grid
		$colio_id = "#colio_{$_id}";
		
		echo "$colio_id .colio-inner { margin: 0 {$item_margin}px {$item_margin}px 0; }";
		echo "$colio_id .colio-button { background-color: $item_button_color; }";
		echo "$colio_id .colio-view:before { background-color: $item_hover_color; opacity: $item_hover_opacity; } ";
		echo "$colio_id .colio-summary h4 a { color: $item_title_color; }";
		echo "$colio_id .colio-summary h4 a:hover { color: $item_title_hover_color; }";
		echo "$colio_id .colio-summary h4 { font-size: {$item_title_font_size}px; }";
		if( $item_title_font !== 'inherit') echo "$colio_id .colio-summary h4 { font-family: $item_title_font, sans-serif; }"; 
		echo "$colio_id .colio-summary p {color: $item_excerpt_color; }"; 
		echo "$colio_id .colio-summary p {font-size: {$item_excerpt_font_size}px; }";
		if( $item_excerpt_font !== 'inherit') echo "$colio_id .colio-summary p {font-family: $item_excerpt_font, sans-serif; }"; 
		echo "$colio_id .colio-pagination li a:hover, $colio_id .colio-pagination .colio-page-active a { border-color: $item_button_color; }";
		
		// viewport
		$viewport_id = "#colio_viewport_{$_id}";
		
		echo "$viewport_id { margin-right: {$item_margin}px; }";
		echo "$viewport_id a { color: {$colio['theme_color']}; }"; 
		echo "$viewport_id .colio-navigation a, $viewport_id .colio-feed li a, $viewport_id .flex-active { background-color: {$colio['theme_color']}; }";
	
	endforeach; ?>
		
	</style>
		
	<?php
};

add_action('wp_head', 'colio_print_styles');


/**
* Function that exports portfolio settings as "window.colio_options" JS variable
*/

function colio_js_options(){

	// array with settings for every portfolio, where portfolio _id is a key
	$all = array();
		
	foreach( colio_list_options() as $option_id) {
	
		// get portfolio settings
		$settings = colio_get_option($option_id);
				
		// add some options from General section as we will need them later in init.js
		$options = array_merge($settings['colio'], array(
			'layout' => $settings['layout'],
			'transition_duration' => $settings['transition_duration'],
			'transition_effect' => $settings['transition_effect'],
			'animate_position' => $settings['animate_position'],
			'pagination' => $settings['pagination'],
			'pagination_num' => $settings['pagination_num']
		));
		
		// rename keys from "option_name" to "optionName"
		foreach( $options as $key => $value ) {
			if( preg_match_all('/_(\w)/', $key, $match, PREG_SET_ORDER) ) {
				$new_key = $key;
				foreach($match as $m) {
					$new_key = str_replace( $m[0], strtoupper($m[1]), $new_key );
				}
				unset($options[$key]);
				$options[$new_key] = $value;
			}
		}
		
		// convert array to JSON
		$all[$option_id] = json_encode($options);
	}
	
	wp_localize_script('colio', 'colio_options', $all);
	
}

add_action('wp_enqueue_scripts', 'colio_js_options');


/**
* Function to get HTML for portfolio filters
*
* @param array $items Colio Items posts as array
* @param string $filters_style Style to display filters
* @return string HTML for filters
*/

function colio_get_filters($items, $filters_style) {

	// check if called properly
	if( empty($items) ) {
		return;
	}
			
	// get tag slugs assigned to every Colio Item post
	$tag_slugs = array();	
	foreach($items as $item) {
		$item_tag_slugs = wp_get_object_terms($item->ID, 'colio_tag', array('fields'=>'slugs'));
		if($item_tag_slugs && !is_wp_error($item_tag_slugs)) {
			$tag_slugs = array_merge($tag_slugs, $item_tag_slugs);
		}
	}
	
	// remove duplicated and sort
	if( !empty($tag_slugs) ) {
		$tag_slugs = array_unique($tag_slugs); sort($tag_slugs);
	} else {
		return;
	}
	
	// get terms for tag slugs
	$filter_tags = array();
	foreach($tag_slugs as $tag_slug) {
		$filter_tags[] = get_term_by('slug', $tag_slug, 'colio_tag');
	}
			
	// dispay filters as list
	if( $filters_style == 'list' ) {
			
		// "show all" filter
		$list_items = '<li><a href="#" class="colio-disable-filters" title="Show all">&times;</a></li>';
		foreach( $filter_tags as $tag ) {
			$list_items .= '<li><a href="#' . $tag->slug . '" title="' . 
			esc_attr( sprintf(__('%s items', 'colio'), $tag->count) ) . '">' . ucwords($tag->name) . '</a></li>';
		}

		return '<ul class="colio-filters">' . $list_items . '</ul>';
	
	} else { // or as select dropdown
	
		$options = '<option value="">-</option>'; // "show all" option
		foreach( $filter_tags as $tag ) {
			$options .= '<option value="' . $tag->slug . '">' . ucwords($tag->name)  . '</option>';
		}
		
		return '<select class="colio-filters">' . $options . '</select>';
		
	}	

}


/**
* Filter to modify excerpt length for portfolio items. Filter uses global 
* $colio_settings variable with current portfolio settings in Loop
*
* @param int $length Current excerpt $length
*/

function colio_thumb_excerpt_length($length){
	global $colio_settings;
	if( is_array($colio_settings) ) {
		return $colio_settings['item_excerpt_length'];
	} else {
		return $length;
	}	
}


/**
* Public. Function to return html for portfolio
* 
* @param string $portfolio_id Portfolio ID
* @param bool $echo Echo html if true (default). False to return
*/

function get_colio($portfolio_id, $echo = true) {
	global $post;

	// get portfolio settings
	foreach( colio_list_options() as $option_id ) {
		$settings = colio_get_option($option_id);
		if( is_array($settings) && $settings['id'] == $portfolio_id ) {
			break;
		} else {
			$settings = false;
		}
	}
	
	// show error if portfolio was not found
	if( ! $settings ) {
		$html = sprintf( __('There is no portfolio with ID "%s"', 'colio'), $portfolio_id );
		if( $echo ) {
			echo $html;
			exit();
		} else {
			return $html;
		}
	}
		
	// query "Colio Items" posts
	$tax_query = array();
	if( !empty($settings['groups']) ) {
		$tax_query[] = array(
			'taxonomy' => 'colio_group',
			'field' => 'term_id',
			'terms' => $settings['groups']
		);
	}
	$query = new WP_Query( array(
		'post_type' => 'colio_item',
		'post_status' => 'publish',
		'tax_query' => $tax_query,
		'order' => $settings['order'],
		'orderby' => $settings['orderby'],
		'posts_per_page' => -1
	) );
	
	// check if query is not empty
	if( $query->have_posts() ) {
	
		// add current portfolio settings to $GLOBALS
		$GLOBALS['colio_settings'] = $settings;
		
		// override excerpt length for thumbs
		add_filter('excerpt_length', 'colio_thumb_excerpt_length', 99);
	
		// classes that will be assigned to colio wrap div
		$wrap_class = array();
		$wrap_class[] = 'colio-wrap';
		$wrap_class[] = 'colio-grid' . $settings['columns'];
		$wrap_class[] = $settings['item_padding'] ? 'colio-thumb-padding' : '';
		$wrap_class[] = $settings['item_zoom'] ? 'colio-thumb-zoom' : '';
		$wrap_class[] = $settings['filters'] ? 'colio-filters-' . $settings['filters_align'] : '';
		$wrap_class[] = 'colio-effect-' . $settings['transition_effect'];
		$wrap_class = apply_filters('colio_wrap_class', $wrap_class);
				
		// start colio wrap div
		$html = '<div id="colio_' . $settings['_id'] . '" class="' . implode(' ', (array) $wrap_class) . '">';
				
		// add filters menu
		if( $settings['filters'] ) {
			$html .= colio_get_filters($query->posts, $settings['filters_style']);
		}
						
		// add "Colio Items" thumbs
		$html .= '<ul class="colio-list">';
		
		// The Loop	
		while( $query->have_posts() ) : $query->the_post();
		
			// skip items without featured images
			if( ! has_post_thumbnail() ) {
				continue;
			}
			
			// get item excerpt
			$item_excerpt = '';
			if( $settings['item_excerpt'] ) {
				$item_excerpt = get_the_excerpt();
			}
			
			// thumb inner html
			$item_thumb_inner = '<div class="colio-inner">' . 
				'<div class="colio-thumb">' . 
					'<div class="colio-view">' .
						'<a class="colio-button colio-link" href="#">' . 
							$settings['item_button_text'] . 
						'</a>' . 
					'</div>' . 
					get_the_post_thumbnail($post->ID, ($settings['layout'] == 'fitRows' ? 'colio-item-thumb' : 'colio-item-thumb-nocrop')) .
				'</div>' .
				'<div class="colio-summary">' . 
					'<h4><a class="colio-link" href="#">' . get_the_title() . '</a></h4>' .
					'<p>' . $item_excerpt . '</p>' .
				'</div>' .
			'</div>';
			
			// get post tags
			$item_tags = wp_get_object_terms($post->ID, 'colio_tag', array('fields'=>'slugs'));
			if( empty($item_tags) || is_wp_error($item_tags) ) {
				$item_tags = array();
			}
			
			// item thumb class
			$item_thumb_class = apply_filters('item_thumb_class', array(), $post);
						
			// add thumb to list
			$html .=  '<li class="' . esc_attr(implode(' ', $item_thumb_class)) . '" data-content="' . 
			esc_url( add_query_arg('portfolio_id', $settings['id'], get_permalink()) ) .'" data-tags="' .
			implode(' ', $item_tags) . '" data-hash="#' . esc_attr($post->post_name) . '">' .
			apply_filters('colio_thumb', $item_thumb_inner, $post) . '</li>';

		endwhile; // The Loop
		
		// close list with thumbs
		$html .= '</ul>';
		
		// close colio wrap div
		$html .= '</div>';		
				
		// restore $post of the main query
		wp_reset_postdata();
		
		// remove excerpt length filter
		remove_filter('excerpt_length', 'colio_excerpt_length', 99);
	
		// unset portfolio settings
		unset($GLOBALS['colio_settings']);
				
	} else {
		$html = __('This portfolio has no items. Please go to "Colio->Items" to add some items', 'colio');
	}
	
	// return or echo html
	if ( ! $echo ) {
		return $html;
	}
	echo $html;
	
}


/** Use custom template to handle colio item post type 
	instead of single.php in theme directory */

function colio_item_template($single_template) {
	global $post;
	if($post->post_type == 'colio_item') {
		return COLIO_PLUGIN_DIR . '/colio-item.php';
	}	
	return $single_template;
}

add_filter('single_template', 'colio_item_template');


/**
* Register shortcode as [colio id="my_portfolio"]
*/

function colio_shortcode( $atts ) {

	// check if "id" attribute is provided
	if( ! isset($atts['id']) ) {
		return __('You should specify ID of portfolio, e.g. [colio id="my_portfolio"]', 'colio');
	}
		
	// return html for portfolio
	return get_colio( colio_sanitize_name($atts['id']), false );
}

add_shortcode('colio', 'colio_shortcode');



/** COLIO PLUGIN QUICK HOW-TO
===========================================================


FILTERS
---
						
"colio_wrap_class":		filter to add/remove classes that will be assigned to portfolio grid wrapper. Accepts array 
						with classes as argument. Must return array as well.
						
"colio_thumb":			filter to modify HTML for item thumb before it's inserted into portfolio grid. Filter accepts
						thumb HTML as first argument, item $post object as second.
												
"colio_item_class":		filter to add/remove classes that will be assigned to item wrapper in colio viewport. 
						Accepts array with classes as first argument, item $post object as second. Must return
						array as well.
												
"colio_item_subtitle":	filter to modify text that is displayed as item subtitle in colio viewport. By default
						subtitle displays a date. Filter accepts date as first argument, item $post 
						object as second.
						

If you need to get settings for specific portfolio you can use "global $colio_settings;" variable in filter functions

						
ACTION HOOKS	
---		

"colio_item_before_main_content":	use this hook to insert text/html before item content in colio viewport.
		 							Function accepts item $post object as argument

"colio_item_after_main_content":	use this hook to insert text/html after item content in colio viewport.
		 							Function accepts item $post object as argument
		 							
"colio_item_before_social_links":	use this hook to insert text/html before social links in colio viewport.
		 							Function accepts item $post object as argument
		 							
"colio_item_after_social_links":	use this hook to insert text/html after social links in colio viewport.
		 							Function accepts item $post object as argument
		 							
"colio_item_before_side_extra":		use this hook to insert text/html before extra photos (feed or slider) in colio
									viewport. Function accepts item $post object as argument
		 							
"colio_item_after_side_extra":		use this hook to insert text/html after extra photos (feed or slider) in colio
									viewport. Function accepts item $post object as argument


Please note that in Colio WP v2.0 next filters are not available any more - "colio_content", "colio_content_main", "colio_content_side"!


*/

?>